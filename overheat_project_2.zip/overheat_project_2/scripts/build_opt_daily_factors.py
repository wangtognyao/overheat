# -*- coding: utf-8 -*-
from __future__ import annotations

import argparse
import sys
from pathlib import Path
sys.path.insert(0,str(Path(__file__).resolve().parents[1]))

import numpy as np
import pandas as pd
from overheat.config import Paths

from overheat.io_utils import safe_read_pickle


def _to_dt(s: pd.Series) -> pd.Series:
    return pd.to_datetime(s, errors="coerce")

def _collect_parquet_paths(option_root: Path, name: str) -> list[Path]:
    p_file = option_root / f"{name}.parquet"
    if p_file.exists():
        return [p_file]
    p_dir = option_root / name
    if p_dir.exists():
        return sorted(p_dir.glob("*.parquet"))
    return []

def _read_parquet_concat(
    paths: list[Path],
    columns: list[str],
    date_col: str,
    since_dt: pd.Timestamp | None,
) -> pd.DataFrame:
    frames: list[pd.DataFrame] = []
    for p in paths:
        try:
            df = pd.read_parquet(p, columns=columns)
        except Exception as e:
            raise RuntimeError(f"Parquet read failed: {p}\n{type(e).__name__}: {e}") from e
        if date_col not in df.columns:
            raise KeyError(f"Missing {date_col} in {p}")
        df[date_col] = _to_dt(df[date_col])
        df = df.dropna(subset=[date_col])
        if since_dt is not None:
            df = df[df[date_col] > since_dt]
        frames.append(df)
    if not frames:
        return pd.DataFrame(columns=columns)
    return pd.concat(frames, axis=0, ignore_index=True)


def build_gamma_conc(option_root: Path, out_path: Path, since: str | None = None) -> pd.DataFrame:
    """
    Build/append daily gamma concentration:
      gamma_conc = log1p( sum( abs(GAMMA) * OPEN_INT ) )

    Required (large, parquet):
      - option_root/mkt_optd/*.parquet (or mkt_optd.parquet)
      - option_root/opt_risk_ind/*.parquet (or opt_risk_ind.parquet)
    Fallback (legacy):
      - option_root/mkt_optd.pkl
      - option_root/opt_risk_ind.pkl

    First run can be heavy (pickles are large).
    """
    optd_parquets = _collect_parquet_paths(option_root, "mkt_optd")
    risk_parquets = _collect_parquet_paths(option_root, "opt_risk_ind")
    mkt_optd_path = option_root / "mkt_optd.pkl"
    risk_path = option_root / "opt_risk_ind.pkl"
    if not optd_parquets and not mkt_optd_path.exists():
        raise FileNotFoundError("Need mkt_optd parquet or pkl under option_root")
    if not risk_parquets and not risk_path.exists():
        raise FileNotFoundError("Need opt_risk_ind parquet or pkl under option_root")

    existed = pd.DataFrame()
    if out_path.exists():
        try:
            existed = pd.read_parquet(out_path)
            existed.index = pd.to_datetime(existed.index, errors="coerce")
            existed = existed[~existed.index.isna()].sort_index()
        except Exception:
            existed = pd.DataFrame()

    last_date = existed.index.max() if not existed.empty else None
    since_dt = pd.to_datetime(since) if since else last_date

    if optd_parquets:
        optd = _read_parquet_concat(
            optd_parquets,
            ["TRADE_DATE", "SECURITY_ID", "OPT_ID", "OPEN_INT"],
            "TRADE_DATE",
            since_dt,
        )
    else:
        optd = safe_read_pickle(mkt_optd_path)
        if not isinstance(optd, pd.DataFrame):
            raise TypeError("Pickle content must be DataFrame")
        optd = optd[["TRADE_DATE", "SECURITY_ID", "OPT_ID", "OPEN_INT"]].copy()
        optd["TRADE_DATE"] = _to_dt(optd["TRADE_DATE"])
        optd = optd.dropna(subset=["TRADE_DATE"])
        if since_dt is not None:
            optd = optd[optd["TRADE_DATE"] > since_dt]

    if risk_parquets:
        risk = _read_parquet_concat(
            risk_parquets,
            ["DATE", "SECURITY_ID", "OPT_ID", "GAMMA"],
            "DATE",
            since_dt,
        )
    else:
        risk = safe_read_pickle(risk_path)
        if not isinstance(risk, pd.DataFrame):
            raise TypeError("Pickle content must be DataFrame")
        risk = risk[["DATE", "SECURITY_ID", "OPT_ID", "GAMMA"]].copy()
        risk["DATE"] = _to_dt(risk["DATE"])
        risk = risk.dropna(subset=["DATE"])
        if since_dt is not None:
            risk = risk[risk["DATE"] > since_dt]

    if optd.empty or risk.empty:
        return existed

    optd["OPEN_INT"] = pd.to_numeric(optd["OPEN_INT"], errors="coerce")
    risk["GAMMA"] = pd.to_numeric(risk["GAMMA"], errors="coerce")
    optd.rename(columns={"TRADE_DATE": "DATE"}, inplace=True)

    merged = optd.merge(risk, on=["DATE", "SECURITY_ID", "OPT_ID"], how="inner")
    merged = merged.dropna(subset=["OPEN_INT", "GAMMA"])
    if merged.empty:
        return existed

    merged["gamma_oi"] = merged["GAMMA"].abs() * merged["OPEN_INT"].clip(lower=0)

    agg = merged.groupby("DATE", sort=True).agg(
        gamma_oi_sum=("gamma_oi", "sum"),
        oi_sum=("OPEN_INT", "sum"),
        n=("OPT_ID", "count"),
    )
    agg["gamma_conc"] = np.log1p(agg["gamma_oi_sum"])

    out = pd.concat([existed, agg], axis=0)
    out = out[~out.index.duplicated(keep="last")].sort_index()
    out_path.parent.mkdir(parents=True, exist_ok=True)
    out.to_parquet(out_path)
    return out


def main() -> None:
    ap = argparse.ArgumentParser()
    ap.add_argument("--option_root", type=str, default="")
    ap.add_argument("--out_path", type=str, default="")
    ap.add_argument("--since", type=str, default="", help="YYYY-MM-DD; else append from last cached date")
    ap.add_argument("--output_root", type=str, default="output")
    args = ap.parse_args()

    paths = Paths()

    option_root = Path(args.option_root) if args.option_root else paths.option_root
    output_root = Path(args.output_root) if args.output_root else paths.out_root

    out_path = Path(args.out_path) if args.out_path else (output_root / "overheat" / "opt_daily_factors.parquet")

    df = build_gamma_conc(option_root, out_path, since=args.since or None)
    print(f"Saved {len(df)} rows -> {out_path}") 


if __name__ == "__main__":
    main()
