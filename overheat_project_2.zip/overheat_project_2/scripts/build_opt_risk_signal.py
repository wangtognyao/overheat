# -*- coding: utf-8 -*-
from __future__ import annotations

import argparse
import sys
from pathlib import Path
import warnings

import numpy as np
import pandas as pd

sys.path.insert(0,str(Path(__file__).resolve().parents[1]))

from overheat.config import Paths


def _rolling_z(s: pd.Series, win: int = 252, min_periods: int = 60) -> pd.Series:
    mean = s.rolling(win, min_periods=min_periods).mean()
    std = s.rolling(win, min_periods=min_periods).std()
    return (s - mean) / std.replace(0, np.nan)


def _safe_col(df: pd.DataFrame, col: str) -> pd.Series | None:
    if col not in df.columns:
        return None
    return pd.to_numeric(df[col], errors="coerce")


def _build_signals(f: pd.DataFrame) -> pd.DataFrame:
    out = pd.DataFrame(index=f.index)

    # z-scores for key factors
    z = {}
    for name in [
        "gamma_conc",
        "vega_conc",
        "delta_net",
        "otm_call_buzz",
        "iv_atm_30d",
        "skew_25d_rr",
        "term_slope_60_30",
    ]:
        s = _safe_col(f, name)
        if s is not None:
            z[name] = _rolling_z(s)
            out[f"{name}_z"] = z[name]

    # Greed/top risk conditions
    greed_conds = []
    if "gamma_conc" in z:
        greed_conds.append(z["gamma_conc"] > 1.2)
    if "otm_call_buzz" in z:
        greed_conds.append(z["otm_call_buzz"] > 1.0)
    if "skew_25d_rr" in z:
        greed_conds.append(z["skew_25d_rr"] > 1.0)
    if "iv_atm_30d" in z:
        greed_conds.append(z["iv_atm_30d"] < -0.5)
    if "delta_net" in z:
        greed_conds.append(z["delta_net"] > 0.5)
    if "term_slope_60_30" in z:
        greed_conds.append(z["term_slope_60_30"] > 0.5)

    # Fear/bottom risk conditions
    fear_conds = []
    if "vega_conc" in z:
        fear_conds.append(z["vega_conc"] > 1.2)
    if "iv_atm_30d" in z:
        fear_conds.append(z["iv_atm_30d"] > 1.5)
    if "term_slope_60_30" in z:
        fear_conds.append(z["term_slope_60_30"] < -0.8)
    if "skew_25d_rr" in z:
        fear_conds.append(z["skew_25d_rr"] < -1.0)
    if "delta_net" in z:
        fear_conds.append(z["delta_net"] < -0.5)

    def _score(conds: list[pd.Series]) -> tuple[pd.Series, pd.Series]:
        if not conds:
            return (pd.Series(index=f.index, dtype="float64"), pd.Series(index=f.index, dtype="float64"))
        mat = pd.concat(conds, axis=1)
        valid_cnt = mat.notna().sum(axis=1)
        score = mat.sum(axis=1, min_count=1)
        score = score.where(valid_cnt > 0)
        return score, valid_cnt

    greed_score, greed_cnt = _score(greed_conds)
    fear_score, fear_cnt = _score(fear_conds)

    out["greed_score"] = greed_score
    out["fear_score"] = fear_score

    def _flag(score: pd.Series, cnt: pd.Series) -> pd.Series:
        # require at least 3 available conditions, and >=60% of them triggered
        need = (cnt * 0.6).apply(np.ceil)
        need = need.where(cnt >= 3)
        return (score >= need).astype("float64")

    out["greed_flag"] = _flag(greed_score, greed_cnt)
    out["fear_flag"] = _flag(fear_score, fear_cnt)

    # Total risk signal: 0 normal, 1 mild, 2 strong
    out["risk_signal"] = out["greed_flag"].fillna(0) + out["fear_flag"].fillna(0)

    return out


def _plot_signals(out: pd.DataFrame, fig_path: Path) -> None:
    try:
        import matplotlib.pyplot as plt
    except Exception as e:
        warnings.warn(f"[plot] skip (matplotlib not available): {type(e).__name__}: {e}", RuntimeWarning)
        return

    fig, axes = plt.subplots(3, 1, figsize=(12, 9), sharex=True)

    # 1) Risk signal
    axes[0].plot(out.index, out["risk_signal"], label="risk_signal", color="black")
    axes[0].set_title("Option Risk Turning Signal")
    axes[0].set_ylim(-0.1, 2.1)
    axes[0].grid(alpha=0.3)
    axes[0].legend(loc="upper left")

    # 2) Greed/Fear scores
    if "greed_score" in out.columns:
        axes[1].plot(out.index, out["greed_score"], label="greed_score", color="#d95f02")
    if "fear_score" in out.columns:
        axes[1].plot(out.index, out["fear_score"], label="fear_score", color="#1b9e77")
    axes[1].grid(alpha=0.3)
    axes[1].legend(loc="upper left")

    # 3) Key z-scores (if present)
    for c, color in [
        ("gamma_conc_z", "#7570b3"),
        ("iv_atm_30d_z", "#e7298a"),
        ("skew_25d_rr_z", "#66a61e"),
        ("term_slope_60_30_z", "#e6ab02"),
    ]:
        if c in out.columns:
            axes[2].plot(out.index, out[c], label=c, color=color)
    axes[2].axhline(0, color="gray", linewidth=0.8)
    axes[2].grid(alpha=0.3)
    axes[2].legend(loc="upper left")

    fig.tight_layout()
    fig_path.parent.mkdir(parents=True, exist_ok=True)
    fig.savefig(fig_path, dpi=150)
    plt.close(fig)


def build_opt_risk_signal(input_path: Path, output_root: Path) -> tuple[Path, Path, int]:
    df = pd.read_parquet(input_path)
    if "date" in df.columns and df.index.name != "date":
        df = df.set_index("date")
    df.index = pd.to_datetime(df.index, errors="coerce")
    df = df[~df.index.isna()].sort_index()

    out = _build_signals(df)
    out_path = output_root / "overheat" / "opt_risk_signal.csv"
    out_path.parent.mkdir(parents=True, exist_ok=True)
    out.to_csv(out_path, encoding="utf-8-sig")

    fig_path = output_root / "overheat" / "opt_risk_signal.png"
    _plot_signals(out, fig_path)

    return out_path, fig_path, len(out)


def main() -> None:
    ap = argparse.ArgumentParser()
    ap.add_argument("--input_path", type=str, default="", help="opt_daily_factors.parquet path")
    ap.add_argument("--output_root", type=str, default="", help="Output root (default: config.OUTPUT_ROOT)")
    args = ap.parse_args()

    paths = Paths()
    out_root = Path(args.output_root) if args.output_root else paths.out_root
    in_path = Path(args.input_path) if args.input_path else (out_root / "overheat" / "opt_daily_factors.parquet")

    if not in_path.exists():
        raise FileNotFoundError(f"Missing opt_daily_factors.parquet: {in_path}")

    out_path, fig_path, n = build_opt_risk_signal(in_path, out_root)

    print(f"Saved {n} rows -> {out_path}")
    print(f"Saved plot -> {fig_path}")


if __name__ == "__main__":
    main()
