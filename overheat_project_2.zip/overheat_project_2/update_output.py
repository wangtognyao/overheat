"""
更新数据
"""
# import sys

# sys.path.append('.')
import os

# 更新期权数据
print('====更新期权数据')
os.system("python /data/wangtongyao/overheat_new/overheat_project_2/scripts/build_opt_daily_factors.py")

# 更新行业过热打分
print('====更新过热打分')
os.system("python /data/wangtongyao/overheat_new/overheat_project_2/overheat_industry/run_industry_daily.py")

# 更新过热分数
print('====更新行业过热打分')
os.system("python /data/wangtongyao/overheat_new/overheat_project_2/run_daily.py")




