# -*- coding: utf-8 -*-
"""Industry overheat monitoring package."""
