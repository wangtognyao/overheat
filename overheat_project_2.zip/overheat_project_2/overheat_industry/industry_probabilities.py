# -*- coding: utf-8 -*-
from __future__ import annotations

import argparse
from pathlib import Path

import numpy as np
import pandas as pd

from overheat_industry.config import Paths
from overheat_industry.industry_map import load_industry_mapping
from overheat_industry.pipeline import load_inputs, prepare_panels


def _pick_chinese_font() -> str:
    try:
        from matplotlib import font_manager
    except Exception:
        return ""

    prefer = [
        "Microsoft YaHei",
        "SimHei",
        "PingFang SC",
        "Hiragino Sans GB",
        "Source Han Sans SC",
        "Noto Sans CJK SC",
        "WenQuanYi Zen Hei",
        "STHeiti",
        "SimSun",
    ]
    available = {f.name for f in font_manager.fontManager.ttflist}
    for name in prefer:
        if name in available:
            return name
    return ""


def _set_matplotlib_font() -> None:
    import matplotlib as mpl

    font_name = _pick_chinese_font()
    if font_name:
        mpl.rcParams["font.sans-serif"] = [font_name]
    mpl.rcParams["axes.unicode_minus"] = False


def _read_scores(path: Path) -> pd.DataFrame:
    df = pd.read_csv(path, encoding="utf-8-sig", index_col=0)
    try:
        df.index = pd.to_datetime(df.index)
    except Exception:
        pass
    return df.sort_index()


def _plot_latest_bar(scores: pd.DataFrame, out_png: Path) -> None:
    import matplotlib.pyplot as plt

    latest_date = scores.index.max()
    if pd.isna(latest_date):
        return
    latest = scores.loc[latest_date].sort_values(ascending=False)
    if latest.empty:
        return
    labels = latest.index.tolist()
    values = latest.values

    plt.figure(figsize=(12, max(6, len(labels) * 0.25)))
    plt.barh(labels[::-1], values[::-1], color="#1f77b4")
    plt.title(f"最新一日行业热度（从高到低）- {latest_date.date()}")
    plt.xlabel("热度分")
    plt.grid(axis="x", alpha=0.3)
    plt.tight_layout()
    plt.savefig(out_png, dpi=150)
    plt.close()


def _future_return_probs(r: pd.Series) -> tuple[float, float, int, int]:
    r = pd.to_numeric(r, errors="coerce")
    fwd1 = r.shift(-1)
    fwd5 = (1.0 + r).rolling(5).apply(np.prod, raw=True).shift(-4) - 1.0
    p1 = float((fwd1 > 0).mean()) if fwd1.notna().any() else np.nan
    p5 = float((fwd5 > 0).mean()) if fwd5.notna().any() else np.nan
    n1 = int(fwd1.notna().sum())
    n5 = int(fwd5.notna().sum())
    return p1, p5, n1, n5


def _parse_industry_label(label: str) -> tuple[str, str]:
    parts = str(label).split("|", 1)
    if len(parts) == 2:
        return parts[0], parts[1]
    return parts[0], ""


def _prob_by_score_bins(score: pd.Series, ret: pd.Series, bins: list[float]) -> list[dict]:
    score = pd.to_numeric(score, errors="coerce")
    ret = pd.to_numeric(ret, errors="coerce")

    fwd1 = ret.shift(-1)
    fwd5 = (1.0 + ret).rolling(5).apply(np.prod, raw=True).shift(-4) - 1.0

    cats = pd.cut(score, bins=bins, right=True, include_lowest=True)
    rows = []
    for cat in cats.cat.categories:
        mask = cats == cat
        s1 = fwd1[mask]
        s5 = fwd5[mask]
        rows.append(
            {
                "score_bin": str(cat),
                "prob_up_1d": float((s1 > 0).mean()) if s1.notna().any() else np.nan,
                "prob_up_5d": float((s5 > 0).mean()) if s5.notna().any() else np.nan,
                "n_obs_1d": int(s1.notna().sum()),
                "n_obs_5d": int(s5.notna().sum()),
            }
        )
    return rows


def main() -> None:
    ap = argparse.ArgumentParser()
    ap.add_argument("--industry_source", choices=["sw", "citics"], default="sw")
    ap.add_argument("--min_stocks", type=int, default=10)
    ap.add_argument(
        "--scores",
        type=str,
        default="overheat_industry/output/industry_scores.csv",
        help="industry_scores.csv path",
    )
    ap.add_argument(
        "--out_dir",
        type=str,
        default="overheat_industry/output",
        help="Output directory for charts and tables",
    )
    ap.add_argument(
        "--score_bins",
        type=str,
        default="0,35,55,75,100",
        help="Comma-separated score bin edges for conditional probabilities",
    )
    args = ap.parse_args()

    out_dir = Path(args.out_dir)
    out_dir.mkdir(parents=True, exist_ok=True)

    # 1) Bar chart of latest industry scores
    _set_matplotlib_font()
    score_df = _read_scores(Path(args.scores))
    _plot_latest_bar(score_df, out_dir / "industry_latest_bar.png")

    # 2) Conditional future return probabilities by score bins (equal-weight returns)
    paths = Paths()
    ind_map = load_industry_mapping(paths.pkl_root, source=args.industry_source)
    inp = load_inputs(paths.basic_root, paths.pkl_root)
    panels = prepare_panels(inp)
    scores = _read_scores(Path(args.scores))

    try:
        bins = [float(x) for x in args.score_bins.split(",") if x.strip() != ""]
    except Exception:
        raise ValueError(f"Invalid --score_bins: {args.score_bins}")
    if len(bins) < 2:
        raise ValueError("score_bins must have at least 2 edges")

    rows = []
    for col in scores.columns:
        ind_code, ind_name = _parse_industry_label(col)
        g = ind_map[ind_map["ind_code"] == ind_code]
        stocks = [s for s in g.index if s in panels.pctchg.columns]
        stock_cnt = len(stocks)
        if stock_cnt < args.min_stocks:
            continue

        pctchg = panels.pctchg.reindex(columns=stocks)
        # equal-weight daily return (pctchg is in percent)
        ret = pctchg.mean(axis=1, skipna=True) / 100.0
        score = scores[col].reindex(ret.index)
        for row in _prob_by_score_bins(score, ret, bins):
            row.update(
                {
                    "ind_code": ind_code,
                    "ind_name": ind_name,
                    "stock_cnt": stock_cnt,
                }
            )
            rows.append(row)

    prob_df = pd.DataFrame(rows)
    prob_df = prob_df.sort_values(["ind_code", "score_bin"])
    prob_df.to_csv(out_dir / "industry_up_probs_by_score_bin.csv", index=False, encoding="utf-8-sig")

    print(f"Saved chart -> {out_dir / 'industry_latest_bar.png'}")
    print(f"Saved table -> {out_dir / 'industry_up_probs_by_score_bin.csv'}")


if __name__ == "__main__":
    main()
