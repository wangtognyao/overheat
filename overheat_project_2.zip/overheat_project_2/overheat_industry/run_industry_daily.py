# -*- coding: utf-8 -*-
from __future__ import annotations

import argparse
from pathlib import Path

import pandas as pd

if __package__ in (None, ""):
    import sys

    sys.path.append(str(Path(__file__).resolve().parents[1]))

from overheat_industry.config import Paths, MODULE_WEIGHTS
from overheat_industry.industry_map import load_industry_mapping
from overheat_industry.pipeline import load_inputs, prepare_panels, compute_industry_features
from overheat_industry.scoring import compute_scores


def _save_csv(df: pd.DataFrame, path: Path) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    df.to_csv(path, encoding="utf-8-sig")


def _pick_chinese_font() -> str:
    try:
        from matplotlib import font_manager
    except Exception:
        return ""

    prefer = [
        "Microsoft YaHei",
        "SimHei",
        "PingFang SC",
        "Hiragino Sans GB",
        "Source Han Sans SC",
        "Noto Sans CJK SC",
        "WenQuanYi Zen Hei",
        "STHeiti",
        "SimSun",
    ]
    available = {f.name for f in font_manager.fontManager.ttflist}
    for name in prefer:
        if name in available:
            return name
    return ""


def _set_matplotlib_font() -> None:
    import matplotlib as mpl

    font_name = _pick_chinese_font()
    if font_name:
        mpl.rcParams["font.sans-serif"] = [font_name]
    mpl.rcParams["axes.unicode_minus"] = False


def _plot_latest_stacked(
    mod_latest: pd.DataFrame,
    out_png: Path,
    total_series: pd.Series | None = None,
    latest_date: pd.Timestamp | None = None,
) -> None:
    import matplotlib.pyplot as plt

    if mod_latest.empty:
        return

    # Build weighted contributions so stacked total stays in 0-100 range
    weight_series = pd.Series(MODULE_WEIGHTS, dtype="float64")
    total_weight = weight_series.sum() if weight_series.sum() > 0 else 1.0
    weight_series = weight_series / total_weight

    # Normalize weights per row to handle missing modules
    valid_mask = mod_latest.notna()
    w_norm = valid_mask.mul(weight_series, axis=1)
    w_sum = w_norm.sum(axis=1).replace(0, pd.NA)
    w_norm = w_norm.div(w_sum, axis=0)

    contrib = mod_latest.mul(w_norm)

    # Sort by weighted total score
    total = contrib.sum(axis=1)
    if total_series is not None and not total_series.empty:
        total_series = total_series.reindex(mod_latest.index)
        order = total_series.sort_values(ascending=False).index
    else:
        order = total.sort_values(ascending=False).index
    mod_latest = mod_latest.loc[order]
    contrib = contrib.loc[order]

    # Convert index to Chinese industry names if available
    mod_latest = mod_latest.copy()
    name_index = [s.split("|", 1)[1] if "|" in s else s for s in map(str, mod_latest.index)]
    mod_latest.index = name_index
    contrib = contrib.copy()
    contrib.index = name_index

    height = max(6, len(mod_latest) * 0.28)
    fig, ax = plt.subplots(figsize=(12, height))
    bottom = pd.Series(0.0, index=mod_latest.index)
    colors = ["#4c78a8", "#f58518", "#54a24b", "#e45756"]
    label_map = {
        "A_Funds": "A_资金",
        "B_Leverage": "B_杠杆",
        "C_Breadth": "C_广度",
        "D_Valuation": "D_估值",
    }
    for i, col in enumerate(mod_latest.columns):
        label = label_map.get(col, col)
        vals = contrib[col].fillna(0.0)
        ax.barh(mod_latest.index, vals, left=bottom, label=label, color=colors[i % len(colors)])
        # annotate segment values inside bars (skip tiny segments)
        raw_vals = mod_latest[col].fillna(0.0)
        for idx, v in vals.items():
            if v >= 2.0:
                x = bottom.loc[idx] + v / 2.0
                # show module raw score inside the weighted segment
                ax.text(x, idx, f"{raw_vals.loc[idx]:.1f}", va="center", ha="center", fontsize=7, color="white")
        bottom = bottom + vals

    date_str = f"{latest_date.date()}" if latest_date is not None else ""
    ax.set_title(f"最新一日行业热度（模块分数堆叠） {date_str}".strip())
    ax.set_xlabel("热度分")
    ax.grid(axis="x", alpha=0.3)
    ax.legend(ncol=2, fontsize=8)
    ax.invert_yaxis()

    # annotate total score at the end of each stacked bar
    if total_series is not None:
        total_series = total_series.copy()
        total_series.index = [
            s.split("|", 1)[1] if "|" in s else s for s in map(str, total_series.index)
        ]
        totals = total_series.reindex(mod_latest.index)
    else:
        totals = contrib.sum(axis=1)
    for idx, val in totals.items():
        if pd.isna(val):
            continue
        ax.text(val + 0.3, idx, f"{val:.1f}", va="center", ha="left", fontsize=8, color="#333333")

    fig.tight_layout()
    out_png.parent.mkdir(parents=True, exist_ok=True)
    fig.savefig(out_png, dpi=150)
    plt.close(fig)


def _build_output_columns(ind_code: str, ind_name: str) -> str:
    name = (ind_name or "").strip()
    if name:
        return f"{ind_code}|{name}"
    return ind_code


def main() -> None:
    ap = argparse.ArgumentParser()
    ap.add_argument("--industry_source", choices=["sw", "citics"], default="sw")
    ap.add_argument("--min_stocks", type=int, default=10, help="Min stocks per industry to compute scores.")
    ap.add_argument("--out_dir", type=str, default="", help="Output dir (default: ./overheat_industry/output)")
    args = ap.parse_args()

    paths = Paths()
    out_dir = Path(args.out_dir) if args.out_dir else Path("overheat_industry") / "output"
    out_dir.mkdir(parents=True, exist_ok=True)

    ind_map = load_industry_mapping(paths.pkl_root, source=args.industry_source)

    inp = load_inputs(paths.basic_root, paths.pkl_root)
    panels = prepare_panels(inp)

    score_panel = pd.DataFrame(index=panels.calendar)
    module_cols: dict[str, pd.Series] = {}
    meta_rows = []

    for ind_code, g in ind_map.groupby("ind_code"):
        ind_name = g["ind_name"].iloc[0] if "ind_name" in g.columns and not g.empty else ""
        stocks = [s for s in g.index if s in panels.amount.columns]
        stock_cnt = len(stocks)

        meta_rows.append(
            {
                "ind_code": ind_code,
                "ind_name": ind_name,
                "stock_cnt": stock_cnt,
            }
        )

        col_name = _build_output_columns(ind_code, ind_name)
        if stock_cnt < args.min_stocks:
            score_panel[col_name] = pd.Series(index=panels.calendar, dtype="float64")
            for mod in ["A_Funds", "B_Leverage", "C_Breadth", "D_Valuation", "OverheatScore"]:
                module_cols[f"{col_name}|{mod}"] = pd.Series(index=panels.calendar, dtype="float64")
            continue

        feat = compute_industry_features(panels, stocks)
        _, m_scores = compute_scores(feat)
        score_panel[col_name] = m_scores["OverheatScore"]

        for mod in [c for c in m_scores.columns if c != "OverheatScore"]:
            module_cols[f"{col_name}|{mod}"] = m_scores[mod]
        module_cols[f"{col_name}|OverheatScore"] = m_scores["OverheatScore"]

    _save_csv(score_panel, out_dir / "industry_scores.csv")

    module_panel = pd.DataFrame(module_cols, index=panels.calendar)
    _save_csv(module_panel, out_dir / "industry_modules.csv")

    meta = pd.DataFrame(meta_rows).sort_values(["stock_cnt", "ind_code"], ascending=[False, True])
    _save_csv(meta, out_dir / "industry_meta.csv")

    if not score_panel.empty:
        latest = score_panel.iloc[-1].to_frame("score")
        latest["ind_code"] = [str(v).split("|", 1)[0] for v in latest.index]
        latest = latest.reset_index(drop=True)
        latest = latest.merge(meta, on="ind_code", how="left")
        latest = latest.sort_values("score", ascending=False)
        _save_csv(latest, out_dir / "industry_latest.csv")

    # Plot latest day stacked bar (module scores)
    if not module_panel.empty:
        latest_date = module_panel.index.max()
        if pd.notna(latest_date):
            cols = [c for c in module_panel.columns if c.endswith("|OverheatScore") is False]
            mod_latest = module_panel.loc[latest_date, cols]
            mod_latest = mod_latest.dropna()
            if not mod_latest.empty:
                # reshape to DataFrame: index=industry, columns=modules
                tmp = mod_latest.rename("score").to_frame()
                tmp["industry"] = tmp.index.str.rsplit("|", n=1).str[0]
                tmp["module"] = tmp.index.str.rsplit("|", n=1).str[-1]
                pivot = tmp.pivot_table(index="industry", columns="module", values="score", aggfunc="first")
                total_latest = score_panel.loc[latest_date] if latest_date in score_panel.index else None
                if total_latest is not None:
                    total_latest = total_latest.rename("total")
                _set_matplotlib_font()
                date_tag = latest_date.strftime("%Y%m%d")
                _plot_latest_stacked(
                    pivot,
                    out_dir / f"industry_{date_tag}.png",
                    total_series=total_latest,
                    latest_date=latest_date,
                )

    print(f"Saved -> {out_dir}")


if __name__ == "__main__":
    main()
