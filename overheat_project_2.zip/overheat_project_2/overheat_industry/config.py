# -*- coding: utf-8 -*-
from __future__ import annotations

from dataclasses import dataclass
from pathlib import Path

# Reuse base data roots from the main project config.
from overheat.config_v2 import (
    DATA_ROOT,
    BASIC_ROOT,
    PKL_ROOT,
    OUTPUT_ROOT,
    HOT_LINE,
    WARM_LINE,
    COOL_LINE,
    ROLLING_Z_WIN,
    Z_CLIP,
    MIN_HISTORY,
)

# ========== Industry classification source files (under pkl_data) ==========
SW_INDUSTRY_FILE = "sw_industry.csv"
CITICS_INDUSTRY_FILE = "citics_industry.csv"

# ========== Industry scoring weights (no options/macro by default) ==========
MODULE_WEIGHTS = {
    "A_Funds": 0.30,
    "B_Leverage": 0.20,
    "C_Breadth": 0.30,
    "D_Valuation": 0.20,
}

FEATURE_WEIGHTS = {
    "A_Funds": {
        "amt_total": 0.55,
        "amt_trend": 0.45,
    },
    "B_Leverage": {
        "margin_total": 0.60,
        "margin_chg_20d": 0.40,
    },
    "C_Breadth": {
        "adv_ratio": 0.40,
        "above_ma20": 0.40,
        "limit_down_ratio": 0.20,
    },
    "D_Valuation": {
        "pb_wavg": 0.55,
        "pe_wavg": 0.45,
    },
}

FEATURE_DIRECTION_POSITIVE = {
    "amt_total": True,
    "amt_trend": True,
    "margin_total": True,
    "margin_chg_20d": True,
    "adv_ratio": True,
    "above_ma20": True,
    "limit_down_ratio": False,
    "pb_wavg": True,
    "pe_wavg": True,
}


@dataclass(frozen=True)
class Paths:
    basic_root: Path = BASIC_ROOT
    pkl_root: Path = PKL_ROOT
    out_root: Path = OUTPUT_ROOT
