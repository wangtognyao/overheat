# -*- coding: utf-8 -*-
from __future__ import annotations

from dataclasses import dataclass
from pathlib import Path

import numpy as np
import pandas as pd

from overheat.feature_utils import mask_by_trade
from overheat.io_utils import load_wide_panel
from overheat.modules.a_funds import compute_features as compute_a_funds
from overheat.modules.b_leverage import compute_features as compute_b_leverage
from overheat.modules.c_breadth import compute_features as compute_c_breadth
from overheat.modules.d_valuation import compute_features as compute_d_valuation


@dataclass
class IndustryInputs:
    trade_mask: pd.DataFrame | None
    amount: pd.DataFrame
    pctchg: pd.DataFrame
    adjclose: pd.DataFrame
    mv: pd.DataFrame
    pb: pd.DataFrame
    pe: pd.DataFrame
    margin: pd.DataFrame
    limit_status: pd.DataFrame


def load_inputs(basic_root: Path, pkl_root: Path) -> IndustryInputs:
    trade_path = pkl_root / "trade_stock.pkl"
    trade_mask = load_wide_panel(trade_path) if trade_path.exists() else None

    amount = load_wide_panel(basic_root / "AShareEODPrices" / "S_DQ_AMOUNT.pkl")
    pctchg = load_wide_panel(basic_root / "AShareEODPrices" / "S_DQ_PCTCHANGE.pkl")
    adjclose = load_wide_panel(basic_root / "AShareEODPrices" / "S_DQ_ADJCLOSE.pkl")
    mv = load_wide_panel(basic_root / "AShareEODDerivativeIndicator" / "S_VAL_MV.pkl")
    pb = load_wide_panel(basic_root / "AShareEODDerivativeIndicator" / "S_VAL_PB_NEW.pkl")
    pe = load_wide_panel(basic_root / "AShareEODDerivativeIndicator" / "S_VAL_PE_TTM.pkl")
    margin = load_wide_panel(basic_root / "AShareMarginTrade" / "S_MARGIN_MARGINTRADEBALANCE.pkl")
    limit_status = load_wide_panel(basic_root / "AShareEODDerivativeIndicator" / "UP_DOWN_LIMIT_STATUS.pkl")

    return IndustryInputs(
        trade_mask=trade_mask,
        amount=amount,
        pctchg=pctchg,
        adjclose=adjclose,
        mv=mv,
        pb=pb,
        pe=pe,
        margin=margin,
        limit_status=limit_status,
    )


@dataclass
class PreparedPanels:
    calendar: pd.DatetimeIndex
    trade_mask: pd.DataFrame | None
    amount: pd.DataFrame
    pctchg: pd.DataFrame
    adjclose: pd.DataFrame
    mv: pd.DataFrame
    pb: pd.DataFrame
    pe: pd.DataFrame
    margin: pd.DataFrame
    limit_status: pd.DataFrame


def prepare_panels(inp: IndustryInputs) -> PreparedPanels:
    calendar = inp.amount.index

    def align(x: pd.DataFrame | None):
        if x is None:
            return None
        return x.reindex(calendar)

    trade_mask = align(inp.trade_mask) if inp.trade_mask is not None else None
    amount = align(inp.amount)
    pctchg = align(inp.pctchg)
    adjclose = align(inp.adjclose)
    mv = align(inp.mv)
    pb = align(inp.pb)
    pe = align(inp.pe)
    margin = align(inp.margin)
    limit_status = align(inp.limit_status)

    if trade_mask is not None:
        amount = mask_by_trade(trade_mask, amount)
        pctchg = mask_by_trade(trade_mask, pctchg)
        adjclose = mask_by_trade(trade_mask, adjclose)
        mv = mask_by_trade(trade_mask, mv)
        pb = mask_by_trade(trade_mask, pb)
        pe = mask_by_trade(trade_mask, pe)
        margin = mask_by_trade(trade_mask, margin)
        limit_status = mask_by_trade(trade_mask, limit_status)

    return PreparedPanels(
        calendar=calendar,
        trade_mask=trade_mask,
        amount=amount,
        pctchg=pctchg,
        adjclose=adjclose,
        mv=mv,
        pb=pb,
        pe=pe,
        margin=margin,
        limit_status=limit_status,
    )


def _empty_features(index: pd.DatetimeIndex, cols: list[str]) -> pd.DataFrame:
    return pd.DataFrame({c: pd.Series(index=index, dtype="float64") for c in cols})


def compute_industry_features(p: PreparedPanels, stocks: list[str]) -> pd.DataFrame:
    cols = [c for c in stocks if c in p.amount.columns]
    if not cols:
        return pd.DataFrame(index=p.calendar)

    # Some panels (e.g., margin) may have fewer stocks; use safe reindex to avoid KeyError.
    amount = p.amount.reindex(columns=cols)
    pctchg = p.pctchg.reindex(columns=cols)
    adjclose = p.adjclose.reindex(columns=cols)
    mv = p.mv.reindex(columns=cols)
    pb = p.pb.reindex(columns=cols)
    pe = p.pe.reindex(columns=cols)
    margin = p.margin.reindex(columns=cols)
    limit_status = p.limit_status.reindex(columns=cols)

    feat = pd.DataFrame(index=p.calendar)

    if amount.shape[1] == 0:
        feat = feat.join(_empty_features(p.calendar, ["amt_total", "amt_trend"]))
    else:
        feat = feat.join(compute_a_funds(amount), how="left")

    if margin.shape[1] == 0:
        feat = feat.join(_empty_features(p.calendar, ["margin_total", "margin_chg_20d"]))
    else:
        feat = feat.join(compute_b_leverage(margin), how="left")

    if pctchg.shape[1] == 0 or adjclose.shape[1] == 0 or limit_status.shape[1] == 0:
        feat = feat.join(_empty_features(p.calendar, ["adv_ratio", "above_ma20", "limit_down_ratio"]))
    else:
        feat = feat.join(compute_c_breadth(pctchg, adjclose, limit_status), how="left")

    if mv.shape[1] == 0 or pb.shape[1] == 0 or pe.shape[1] == 0:
        feat = feat.join(_empty_features(p.calendar, ["pb_wavg", "pe_wavg"]))
    else:
        feat = feat.join(compute_d_valuation(mv, pb, pe), how="left")

    # Stabilize scale for level-like columns (same as market pipeline)
    for col in ["amt_total", "margin_total"]:
        if col in feat.columns:
            feat[col] = np.log1p(feat[col])

    return feat
