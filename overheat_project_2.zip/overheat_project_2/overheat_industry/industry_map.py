# -*- coding: utf-8 -*-
from __future__ import annotations

from pathlib import Path

import pandas as pd

from .config import SW_INDUSTRY_FILE, CITICS_INDUSTRY_FILE


def _load_csv(path: Path) -> pd.DataFrame:
    return pd.read_csv(path, encoding="utf-8-sig")


def load_industry_mapping(pkl_root: Path, source: str = "sw") -> pd.DataFrame:
    """Load latest industry classification per stock.

    Returns a DataFrame indexed by stock code with columns:
    ind_code, ind_name, entry_dt, remove_dt, source
    """
    source = source.lower().strip()
    if source == "sw":
        path = pkl_root / SW_INDUSTRY_FILE
        code_col = "SW_IND_CODE"
    elif source == "citics":
        path = pkl_root / CITICS_INDUSTRY_FILE
        code_col = "CITICS_IND_CODE"
    else:
        raise ValueError(f"Unknown industry source: {source}")

    if not path.exists():
        raise FileNotFoundError(f"Missing industry file: {path}")

    df = _load_csv(path)
    need_cols = {"S_INFO_WINDCODE", code_col}
    if not need_cols.issubset(df.columns):
        raise ValueError(f"Industry file missing columns: {need_cols} in {path}")

    name_col = "INDUSTRIESNAME" if "INDUSTRIESNAME" in df.columns else None
    entry_col = "ENTRY_DT" if "ENTRY_DT" in df.columns else None
    remove_col = "REMOVE_DT" if "REMOVE_DT" in df.columns else None

    out = pd.DataFrame()
    out["stock"] = df["S_INFO_WINDCODE"].astype(str)
    out["ind_code"] = df[code_col].astype(str)
    out["ind_name"] = df[name_col].astype(str) if name_col else ""
    if entry_col:
        out["entry_dt"] = pd.to_datetime(df[entry_col], errors="coerce")
    else:
        out["entry_dt"] = pd.NaT
    if remove_col:
        out["remove_dt"] = pd.to_datetime(df[remove_col], errors="coerce")
    else:
        out["remove_dt"] = pd.NaT
    out["source"] = source

    # Pick the latest entry per stock (static membership for full history).
    out["_entry_sort"] = out["entry_dt"].fillna(pd.Timestamp.min)
    out = out.sort_values(["stock", "_entry_sort"])
    out = out.groupby("stock", as_index=False).tail(1)
    out = out.drop(columns=["_entry_sort"])

    out = out[out["ind_code"].notna()]
    out = out.set_index("stock")
    return out
