# -*- coding: utf-8 -*-
from __future__ import annotations

from dataclasses import dataclass
from pathlib import Path
import warnings

import numpy as np
import pandas as pd

from .config import (
    MARKET_PROXY_TICKER,
    ASYNC_FFILL_COLS,
    ASYNC_FFILL_LIMIT,
    ASYNC_FFILL_ONLY_IF_LAST_DAY_MISSING,
    ASYNC_STALE_WARN_DAYS,
    MACRO_ROOT,
    OUTPUT_ROOT,
)
from .io_utils import load_wide_panel, safe_read_pickle, safe_read_parquet
from .feature_utils import mask_by_trade, ffill_tail
from .modules.a_funds import compute_features as compute_a_funds
from .modules.b_leverage import compute_features as compute_b_leverage
from .modules.c_breadth import compute_features as compute_c_breadth
from .modules.d_valuation import compute_features as compute_d_valuation
from .modules.e_options import compute_features as compute_e_options
from .modules.m_macro import compute_features as compute_m_macro


def _apply_async_ffill(
    feat: pd.DataFrame,
    cols: list[str],
    limit: int,
    only_if_last_day_missing: bool,
    stale_warn_days: int,
) -> pd.DataFrame:
    if not cols:
        return feat
    out = feat.copy()
    idx = out.index
    if len(idx) == 0:
        return out
    last_date = idx[-1]

    for col in cols:
        if col not in out.columns:
            continue
        s = out[col]
        if s.empty:
            continue

        last_valid = s.last_valid_index()
        if last_valid is None:
            warnings.warn(f"[async-ffill] {col} has no valid data.", RuntimeWarning)
        else:
            try:
                gap = idx.get_loc(last_date) - idx.get_loc(last_valid)
            except KeyError:
                gap = None
            if gap is not None and stale_warn_days is not None and gap >= stale_warn_days:
                warnings.warn(
                    f"[async-ffill] {col} stale for {gap} days (last valid {last_valid}).",
                    RuntimeWarning,
                )

        if only_if_last_day_missing and not pd.isna(s.iloc[-1]):
            continue
        out[col] = ffill_tail(s, limit=limit)

    return out


def market_proxy_from_fund(option_root: Path, ticker: str = MARKET_PROXY_TICKER) -> pd.Series | None:
    """Try to read market proxy from option_data/mkt_fundd.pkl (e.g. 510300 close)."""
    path = option_root / "mkt_fundd.pkl"
    if not path.exists():
        return None
    try:
        df = safe_read_pickle(path)
    except Exception as e:
        warnings.warn(f"[market-proxy] skip {path.name} (not ready): {type(e).__name__}: {e}", RuntimeWarning)
        return None
    if not isinstance(df, pd.DataFrame):
        return None
    need = {"TRADE_DATE", "CLOSE_PRICE", "TICKER_SYMBOL"}
    if not need.issubset(df.columns):
        return None
    dff = df[df["TICKER_SYMBOL"].astype(str) == str(ticker)].copy()
    if dff.empty:
        return None
    dff["TRADE_DATE"] = pd.to_datetime(dff["TRADE_DATE"], errors="coerce")
    dff = dff.dropna(subset=["TRADE_DATE"]).sort_values("TRADE_DATE")
    dff["CLOSE_PRICE"] = pd.to_numeric(dff["CLOSE_PRICE"], errors="coerce")
    s = pd.Series(dff["CLOSE_PRICE"].values, index=dff["TRADE_DATE"].values)
    s.name = f"proxy_{ticker}"
    return s


def market_proxy_equal_weight(adjclose: pd.DataFrame, trade_mask: pd.DataFrame | None = None) -> pd.Series:
    """Fallback proxy: equal-weight market price (stable)."""
    x = adjclose
    if trade_mask is not None:
        x = mask_by_trade(trade_mask, x)
    s = x.mean(axis=1, skipna=True)
    s.name = "proxy_eqw"
    return s


@dataclass
class FeatureInputs:
    trade_mask: pd.DataFrame | None
    amount: pd.DataFrame
    pctchg: pd.DataFrame
    adjclose: pd.DataFrame
    mv: pd.DataFrame
    pb: pd.DataFrame
    pe: pd.DataFrame
    margin: pd.DataFrame
    limit_status: pd.DataFrame
    opt_stats: pd.DataFrame


def load_inputs(basic_root: Path, option_root: Path, pkl_root: Path) -> FeatureInputs:
    trade_path = pkl_root / "trade_stock.pkl"
    trade_mask = load_wide_panel(trade_path) if trade_path.exists() else None

    amount = load_wide_panel(basic_root / "AShareEODPrices" / "S_DQ_AMOUNT.pkl")
    pctchg = load_wide_panel(basic_root / "AShareEODPrices" / "S_DQ_PCTCHANGE.pkl")
    adjclose = load_wide_panel(basic_root / "AShareEODPrices" / "S_DQ_ADJCLOSE.pkl")
    mv = load_wide_panel(basic_root / "AShareEODDerivativeIndicator" / "S_VAL_MV.pkl")
    pb = load_wide_panel(basic_root / "AShareEODDerivativeIndicator" / "S_VAL_PB_NEW.pkl")
    pe = load_wide_panel(basic_root / "AShareEODDerivativeIndicator" / "S_VAL_PE_TTM.pkl")
    margin = load_wide_panel(basic_root / "AShareMarginTrade" / "S_MARGIN_MARGINTRADEBALANCE.pkl")
    limit_status = load_wide_panel(basic_root / "AShareEODDerivativeIndicator" / "UP_DOWN_LIMIT_STATUS.pkl")

    opt_stats_path = option_root / "mkt_opt_stats.parquet"
    if opt_stats_path.exists():
        opt_stats = safe_read_parquet(opt_stats_path)
    else:
        opt_stats_path = option_root / "mkt_opt_stats.pkl"
        if not opt_stats_path.exists():
            raise FileNotFoundError("Missing mkt_opt_stats.parquet/.pkl under option_root")
        opt_stats = safe_read_pickle(opt_stats_path)
    if not isinstance(opt_stats, pd.DataFrame):
        raise TypeError(f"期权统计文件不是 DataFrame：{opt_stats_path}")
    opt_stats = opt_stats.copy()
    opt_stats["TRADE_DATE"] = pd.to_datetime(opt_stats["TRADE_DATE"], errors="coerce")
    opt_stats = opt_stats.dropna(subset=["TRADE_DATE"]).sort_values("TRADE_DATE")

    return FeatureInputs(
        trade_mask=trade_mask,
        amount=amount,
        pctchg=pctchg,
        adjclose=adjclose,
        mv=mv,
        pb=pb,
        pe=pe,
        margin=margin,
        limit_status=limit_status,
        opt_stats=opt_stats,
    )


def compute_features(inp: FeatureInputs) -> pd.DataFrame:
    """Compute all daily features (modular)."""
    calendar = inp.amount.index

    def align(x: pd.DataFrame | None):
        if x is None:
            return None
        return x.reindex(calendar)

    trade_mask = align(inp.trade_mask) if inp.trade_mask is not None else None
    amount = align(inp.amount)
    pctchg = align(inp.pctchg)
    adjclose = align(inp.adjclose)
    mv = align(inp.mv)
    pb = align(inp.pb)
    pe = align(inp.pe)
    margin = align(inp.margin)
    limit_status = align(inp.limit_status)

    if trade_mask is not None:
        amount = mask_by_trade(trade_mask, amount)
        pctchg = mask_by_trade(trade_mask, pctchg)
        adjclose = mask_by_trade(trade_mask, adjclose)
        mv = mask_by_trade(trade_mask, mv)
        pb = mask_by_trade(trade_mask, pb)
        pe = mask_by_trade(trade_mask, pe)
        margin = mask_by_trade(trade_mask, margin)
        limit_status = mask_by_trade(trade_mask, limit_status)

    feat = pd.DataFrame(index=calendar)
    feat = feat.join(compute_a_funds(amount), how="left")
    feat = feat.join(compute_b_leverage(margin), how="left")
    feat = feat.join(compute_c_breadth(pctchg, adjclose, limit_status), how="left")
    feat = feat.join(compute_d_valuation(mv, pb, pe), how="left")
    feat = feat.join(compute_e_options(inp.opt_stats, calendar, out_root=OUTPUT_ROOT), how="left")

    # Optional macro join
    try:
        macro_df = compute_m_macro(MACRO_ROOT, calendar)
        if macro_df is not None and not macro_df.empty:
            feat = feat.join(macro_df, how="left")
    except Exception as e:
        warnings.warn(f"[macro] skip macro features: {type(e).__name__}: {e}", RuntimeWarning)

    # Stabilize scale
    for col in ["amt_total", "margin_total", "opt_turnover"]:
        if col in feat.columns:
            feat[col] = np.log1p(feat[col])

    feat = _apply_async_ffill(
        feat,
        cols=list(ASYNC_FFILL_COLS),
        limit=ASYNC_FFILL_LIMIT,
        only_if_last_day_missing=ASYNC_FFILL_ONLY_IF_LAST_DAY_MISSING,
        stale_warn_days=ASYNC_STALE_WARN_DAYS,
    )

    return feat


def compute_market_proxy(inp: FeatureInputs, option_root: Path) -> pd.Series:
    s = market_proxy_from_fund(option_root, ticker=MARKET_PROXY_TICKER)
    if s is not None:
        return s
    return market_proxy_equal_weight(inp.adjclose, trade_mask=inp.trade_mask)
