# -*- coding: utf-8 -*-
from __future__ import annotations

import numpy as np
import pandas as pd

from . import config as cfg

def _band(score: float) -> str:
    if np.isnan(score):
        return "（数据不足）"
    if score >= cfg.HOT_LINE:
        return "热区"
    if score >= cfg.WARM_LINE:
        return "偏热"
    if score <= cfg.COOL_LINE:
        return "偏冷"
    return "中性"

def _fmt_delta(x: float) -> str:
    if np.isnan(x):
        return ""
    return f"{x:+.1f}"

def make_daily_message(scores: pd.DataFrame, feature_scores: pd.DataFrame) -> str:
    """输入为全量 DF，函数会取最后两天对比，输出一段可直接发微信的文案。"""
    if scores is None or scores.empty:
        return "（无可用分数）"

    last = scores.iloc[-1]
    prev = scores.iloc[-2] if len(scores) >= 2 else None

    date_str = last.name.strftime("%Y-%m-%d") if hasattr(last.name, "strftime") else str(last.name)

    total = float(last.get("OverheatScore", np.nan))
    total_prev = float(prev.get("OverheatScore", np.nan)) if prev is not None else np.nan
    total_delta = total - total_prev if prev is not None else np.nan

    # 模块
    modules = [c for c in scores.columns if c != "OverheatScore"]
    mod_lines = []
    for m in modules:
        v = float(last.get(m, np.nan))
        dv = v - float(prev.get(m, np.nan)) if prev is not None else np.nan
        name = getattr(cfg, "MODULE_LABELS", {}).get(m, m)
        mod_lines.append(f"- {name}: {v:.1f}{('（'+_fmt_delta(dv)+'）') if prev is not None else ''}")

    # 驱动：找分数变化最大的 3 个特征
    driver_lines = []
    if prev is not None and feature_scores is not None and not feature_scores.empty:
        d = (feature_scores.iloc[-1] - feature_scores.iloc[-2]).dropna()
        if not d.empty:
            top = d.reindex(d.abs().sort_values(ascending=False).index).head(3)
            labels = getattr(cfg, "FEATURE_LABELS", {})
            for k, v in top.items():
                kname = labels.get(k, k)
                driver_lines.append(f"- {kname}: {_fmt_delta(float(v))}")

    # 输出
    lines = []
    lines.append(f"巍总～我更新下 {date_str} 的过热监测（{cfg.HOT_LINE}分为热区分界线）：")
    lines.append(f"1）总分：{total:.1f}（{_band(total)}）{('，较前一日'+_fmt_delta(total_delta)) if prev is not None else ''}")
    lines.append("2）分模块：")
    lines.extend(mod_lines)

    if driver_lines:
        lines.append("3）今日主要变动驱动（分数变化）：")
        lines.extend(driver_lines)

    # 一句话
    if not np.isnan(total):
        if total >= cfg.HOT_LINE:
            comment = "风险提示：整体情绪/拥挤度偏高，建议控制仓位与回撤预案。"
        elif total >= cfg.WARM_LINE:
            comment = "偏热但未极端：若有回撤/震荡，可能更适合做结构与对冲的量化机会。"
        elif total <= cfg.COOL_LINE:
            comment = "偏冷：情绪与资金偏弱，更需关注政策/流动性边际变化。"
        else:
            comment = "中性：更看基本面与结构轮动，关注量能与杠杆是否继续抬升。"
        lines.append(f"4）一句话：{comment}")

    return "\n".join(lines)
