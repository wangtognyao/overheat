# -*- coding: utf-8 -*-
from __future__ import annotations

import pickle
from pathlib import Path
from typing import Optional, Union, Iterable

import numpy as np
import pandas as pd

DateLike = Union[str, int, float, pd.Timestamp]

def safe_read_pickle(path: Path):
    """读 pkl：兼容 EOFError / pickle 错误，失败时抛出更清晰的异常。"""
    try:
        return pd.read_pickle(path)
    except (EOFError, pickle.UnpicklingError, ValueError) as e:
        raise RuntimeError(f"Pickle 文件可能损坏或未下载完整：{path}\n{type(e).__name__}: {e}") from e

def safe_read_parquet(path: Path) -> pd.DataFrame:
    """Read parquet with a clearer error if it fails."""
    try:
        return pd.read_parquet(path)
    except Exception as e:
        raise RuntimeError(f"Parquet read failed: {path}\n{type(e).__name__}: {e}") from e

def parse_date_index(idx: pd.Index) -> pd.DatetimeIndex:
    """把常见的日期索引（int YYYYMMDD / str / datetime）统一成 DatetimeIndex。"""
    if isinstance(idx, pd.DatetimeIndex):
        return idx

    # int like 20260120
    if np.issubdtype(idx.dtype, np.number):
        s = pd.Series(idx.astype("Int64").astype(str))
        dt = pd.to_datetime(s, format="%Y%m%d", errors="coerce")
        if dt.notna().mean() > 0.8:
            return pd.DatetimeIndex(dt)
        # fallback
        return pd.to_datetime(idx, errors="coerce")

    # object / string
    dt = pd.to_datetime(idx, errors="coerce")
    return pd.DatetimeIndex(dt)

def ensure_datetime_index(df: pd.DataFrame) -> pd.DataFrame:
    if not isinstance(df.index, pd.DatetimeIndex):
        df = df.copy()
        df.index = parse_date_index(df.index)
    df = df[~df.index.isna()]
    return df.sort_index()

def load_wide_panel(path: Path) -> pd.DataFrame:
    df = safe_read_pickle(path)
    if not isinstance(df, pd.DataFrame):
        raise TypeError(f"期望 DataFrame：{path}, 实际 {type(df)}")
    return ensure_datetime_index(df)

def load_macro_csv(path: Path) -> pd.Series:
    """macro_data/*csv 统一读成 (date -> value) 的 Series（按日频 forward-fill 由上层做）。"""
    df = pd.read_csv(path, encoding="utf-8-sig")
    # 常见字段：date/value
    if "date" not in df.columns or "value" not in df.columns:
        raise ValueError(f"宏观csv缺少 date/value 列：{path}")
    df["date"] = pd.to_datetime(df["date"], errors="coerce")
    df = df.dropna(subset=["date"]).sort_values("date")
    s = pd.Series(df["value"].values, index=df["date"].values)
    s.name = path.stem
    return s

def align_to_calendar(series_dict: dict[str, pd.Series], calendar: pd.DatetimeIndex) -> pd.DataFrame:
    """把若干序列按交易日历对齐，并 forward-fill。"""
    out = {}
    for k, s in series_dict.items():
        s2 = s.copy()
        s2.index = pd.to_datetime(s2.index)
        out[k] = s2.reindex(calendar).ffill()
    return pd.DataFrame(out, index=calendar)

def save_csv(df: pd.DataFrame, path: Path) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    df.to_csv(path, encoding="utf-8-sig")

def maybe_series(x) -> pd.Series:
    if isinstance(x, pd.Series):
        return x
    if isinstance(x, pd.DataFrame) and x.shape[1] == 1:
        return x.iloc[:, 0]
    raise TypeError(f"无法转为 Series: {type(x)}")
