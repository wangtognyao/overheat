# -*- coding: utf-8 -*-
from __future__ import annotations

from pathlib import Path

import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
import matplotlib.dates as mdates

def plot_overheat(proxy: pd.Series | None, scores: pd.DataFrame, out_png: Path, title: str = "OverheatScore") -> None:
    out_png.parent.mkdir(parents=True, exist_ok=True)

    s = scores["OverheatScore"].dropna()
    if s.empty:
        return

    fig, ax1 = plt.subplots(figsize=(12, 5))
    ax1.plot(s.index, s.values)
    ax1.set_ylabel("OverheatScore (0-100)")
    ax1.set_ylim(0, 100)
    ax1.xaxis.set_major_locator(mdates.AutoDateLocator())
    ax1.xaxis.set_major_formatter(mdates.ConciseDateFormatter(ax1.xaxis.get_major_locator()))
    ax1.set_title(title)

    # 叠加代理价格（右轴）
    if proxy is not None:
        p = proxy.reindex(s.index).ffill()
        ax2 = ax1.twinx()
        ax2.plot(p.index, p.values, linestyle="--")
        ax2.set_ylabel("Market Proxy")

    fig.tight_layout()
    fig.savefig(out_png, dpi=150)
    plt.close(fig)

def plot_subscores(scores: pd.DataFrame, out_png: Path, title: str = "Module Scores") -> None:
    out_png.parent.mkdir(parents=True, exist_ok=True)
    cols = [c for c in scores.columns if c not in ["OverheatScore"]]
    if not cols:
        return
    s = scores[cols].dropna(how="all")
    if s.empty:
        return

    fig, ax = plt.subplots(figsize=(12, 5))
    for c in cols:
        ax.plot(s.index, s[c].values, label=c)
    ax.set_ylim(0, 100)
    ax.set_title(title)
    ax.xaxis.set_major_locator(mdates.AutoDateLocator())
    ax.xaxis.set_major_formatter(mdates.ConciseDateFormatter(ax.xaxis.get_major_locator()))
    ax.legend(ncol=3, fontsize=8)
    fig.tight_layout()
    fig.savefig(out_png, dpi=150)
    plt.close(fig)
