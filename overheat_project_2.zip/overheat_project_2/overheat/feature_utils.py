# -*- coding: utf-8 -*-
from __future__ import annotations

import pandas as pd


def ffill_tail(s: pd.Series, limit: int = 1) -> pd.Series:
    """Forward-fill only the tail of a series (safer for async updates like T+1)."""
    if s is None or s.empty:
        return s
    if limit is None or limit <= 0:
        return s
    k = min(len(s), limit + 1)
    if k <= 1:
        return s
    head = s.iloc[:-k]
    tail = s.iloc[-k:].copy().ffill(limit=limit)
    return pd.concat([head, tail])


def mask_by_trade(trade_mask: pd.DataFrame, x: pd.DataFrame) -> pd.DataFrame:
    """Align trade_mask to x, then set non-tradable cells to NaN."""
    if trade_mask is None:
        return x
    trade_mask = trade_mask.reindex_like(x)
    return x.where(trade_mask.astype(bool))
