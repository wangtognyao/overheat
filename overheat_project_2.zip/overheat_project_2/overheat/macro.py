# -*- coding: utf-8 -*-
from __future__ import annotations

from pathlib import Path
import pandas as pd

from .io_utils import load_macro_csv, align_to_calendar

def compute_macro_features(macro_root: Path, calendar: pd.DatetimeIndex) -> pd.DataFrame:
    mapping = {
        "dr007": "1090000567_dr007.csv",
        "cgb10y": "1090001399_china_gov_bond_yield_10y_cdb.csv",
        "lpr_1y": "1090000378_lpr_1y.csv",
        "shibor_3m": "1090000541_shibor_3m.csv",
        "m2_sa": "1070021972_m2_sa.csv",
        "m1_sa": "1070021973_m1_sa.csv",
        "mlf_net_injection": "1070021958_mlf_net_injection.csv",
        "cpi": "1040005490_cpi_fixed_base_index.csv",
        "ppi": "1040005491_ppi_fixed_base_index.csv",
        "pmi": "1030000011_pmi_manufacturing.csv",
        "industrial_va": "1020021351_industrial_value_added_fixed_base_index.csv",
        "retail_sales": "1110000004_retail_sales_total_value.csv",
        "unemp_urban": "1130007831_urban_survey_unemp_rate_31cities.csv",
        "usdcny": "1080000004_usdcny_mid.csv",
        "dxy": "3010000345_dxy.csv",
        "gold_spot": "2050001068_gold_spot_usd.csv",
        "us10y": "3010200075_us_treasury_yield_curve_10y.csv",
        "aaa_1y": "1090026090_AAA+1y.csv",
    }

    series = {}
    for k, fn in mapping.items():
        p = macro_root / fn
        if p.exists():
            try:
                series[k] = load_macro_csv(p)
            except Exception:
                continue

    if not series:
        return pd.DataFrame(index=calendar)

    df = align_to_calendar(series, calendar)

    if "cgb10y" in df.columns and "dr007" in df.columns:
        df["term_spread"] = df["cgb10y"] - df["dr007"]
    if "aaa_1y" in df.columns and "cgb10y" in df.columns:
        df["credit_spread_1y"] = df["aaa_1y"] - df["cgb10y"]
    if "m2_sa" in df.columns and "m1_sa" in df.columns:
        df["m2_m1_gap"] = df["m2_sa"] - df["m1_sa"]
    if "cpi" in df.columns and "ppi" in df.columns:
        df["cpi_ppi_gap"] = df["cpi"] - df["ppi"]

    return df
