# -*- coding: utf-8 -*-
from __future__ import annotations

from dataclasses import dataclass
from pathlib import Path
import warnings

import numpy as np
import pandas as pd

from .config import (
    LIMIT_UP_CODE,
    LIMIT_DOWN_CODE,
    MARKET_PROXY_TICKER,
    ASYNC_FFILL_COLS,
    ASYNC_FFILL_LIMIT,
    ASYNC_FFILL_ONLY_IF_LAST_DAY_MISSING,
    ASYNC_STALE_WARN_DAYS,
)
from .io_utils import load_wide_panel, safe_read_pickle, safe_read_parquet, ensure_datetime_index

# def ffill_tail(s: pd.Series, limit: int = 1) -> pd.Series:
#     """
#     只对最后几天做 ffill（工程上更安全）
#     limit=1：最多沿用 1 天（典型两融 T+1）
#     """
#     if s is None or s.empty:
#         return s
#     if limit is None or limit <= 0:
#         return s
#     k = min(len(s), limit + 1)
#     head = s.iloc[:-k]
#     tail = s.iloc[-k:].copy().ffill(limit=limit)
#     return pd.concat([head, tail])
def ffill_tail(s: pd.Series, limit: int = 1) -> pd.Series:
    """Forward-fill only the tail (safer for async updates like T+1)."""
    if s is None or s.empty:
        return s
    if limit is None or limit <= 0:
        return s
    k = min(len(s), limit + 1)
    if k <= 1:
        return s
    head = s.iloc[:-k]
    tail = s.iloc[-k:].copy().ffill(limit=limit)
    return pd.concat([head, tail])

def _apply_async_ffill(
    feat: pd.DataFrame,
    cols: list[str],
    limit: int,
    only_if_last_day_missing: bool,
    stale_warn_days: int,
) -> pd.DataFrame:
    if not cols:
        return feat
    out = feat.copy()
    idx = out.index
    last_pos = len(idx) - 1
    last_date = idx[last_pos] if last_pos >= 0 else None

    for col in cols:
        if col not in out.columns:
            continue
        s = out[col]
        if s.empty:
            continue

        last_valid = s.last_valid_index()
        if last_valid is None:
            warnings.warn(f"[async-ffill] {col} has no valid data.", RuntimeWarning)
        else:
            try:
                gap = idx.get_loc(last_date) - idx.get_loc(last_valid)
            except KeyError:
                gap = None
            if gap is not None and stale_warn_days is not None and gap >= stale_warn_days:
                warnings.warn(
                    f"[async-ffill] {col} stale for {gap} days (last valid {last_valid}).",
                    RuntimeWarning,
                )

        if only_if_last_day_missing and not pd.isna(s.iloc[-1]):
            continue
        out[col] = ffill_tail(s, limit=limit)

    return out

def _mask_by_trade(trade_mask: pd.DataFrame, x: pd.DataFrame) -> pd.DataFrame:
    """trade_mask: 1/0; x: wide DF. 对齐后把不可交易置为 NaN."""
    trade_mask = trade_mask.reindex_like(x)
    return x.where(trade_mask.astype(bool))

def market_proxy_from_fund(option_root: Path, ticker: str = MARKET_PROXY_TICKER) -> pd.Series | None:
    """尝试从 option_data/mkt_fundd.pkl 里拿 ETF 收盘价作市场代理。

    注意：mkt_fundd.pkl 如果正在下载/写入，可能出现 EOFError（文件未完整写入）。
    这种情况下应当“跳过并降级”，避免日更任务被阻断。
    """
    path = option_root / "mkt_fundd.pkl"
    if not path.exists():
        return None

    # 文件可能正在下载/写入：safe_read_pickle 会抛 RuntimeError（包装了 EOFError）
    try:
        df = safe_read_pickle(path)
    except Exception as e:
        warnings.warn(f"[market-proxy] skip {path.name} (not ready): {type(e).__name__}: {e}", RuntimeWarning)
        return None

    if not isinstance(df, pd.DataFrame):
        return None
    # 列口径见 data_option.json：TRADE_DATE / CLOSE_PRICE / TICKER_SYMBOL
    cols = set(df.columns)
    if not {"TRADE_DATE", "CLOSE_PRICE", "TICKER_SYMBOL"}.issubset(cols):
        return None
    dff = df[df["TICKER_SYMBOL"].astype(str) == str(ticker)].copy()
    if dff.empty:
        return None
    dff["TRADE_DATE"] = pd.to_datetime(dff["TRADE_DATE"], errors="coerce")
    dff = dff.dropna(subset=["TRADE_DATE"]).sort_values("TRADE_DATE")
    # CLOSE_PRICE 可能是 object，先转数值
    dff["CLOSE_PRICE"] = pd.to_numeric(dff["CLOSE_PRICE"], errors="coerce")
    s = pd.Series(dff["CLOSE_PRICE"].values, index=dff["TRADE_DATE"].values)
    s.name = f"proxy_{ticker}"
    return s


def market_proxy_equal_weight(adjclose: pd.DataFrame, trade_mask: pd.DataFrame | None = None) -> pd.Series:
    """用全市场等权（可用 trade_mask 过滤）当代理价格：更稳健但不等同指数。"""
    x = adjclose
    if trade_mask is not None:
        x = _mask_by_trade(trade_mask, x)
    # 等权：按行 mean（忽略 NaN）
    s = x.mean(axis=1, skipna=True)
    s.name = "proxy_eqw"
    return s

@dataclass
class FeatureInputs:
    trade_mask: pd.DataFrame | None
    amount: pd.DataFrame
    pctchg: pd.DataFrame
    adjclose: pd.DataFrame
    mv: pd.DataFrame
    pb: pd.DataFrame
    pe: pd.DataFrame
    margin: pd.DataFrame
    limit_status: pd.DataFrame
    opt_stats: pd.DataFrame

def load_inputs(basic_root: Path, option_root: Path, pkl_root: Path) -> FeatureInputs:
    # trade universe
    trade_path = pkl_root / "trade_stock.pkl"
    trade_mask = None
    if trade_path.exists():
        trade_mask = load_wide_panel(trade_path)

    # basic panels
    amount = load_wide_panel(basic_root / "AShareEODPrices" / "S_DQ_AMOUNT.pkl")
    pctchg = load_wide_panel(basic_root / "AShareEODPrices" / "S_DQ_PCTCHANGE.pkl")
    adjclose = load_wide_panel(basic_root / "AShareEODPrices" / "S_DQ_ADJCLOSE.pkl")
    mv = load_wide_panel(basic_root / "AShareEODDerivativeIndicator" / "S_VAL_MV.pkl")
    pb = load_wide_panel(basic_root / "AShareEODDerivativeIndicator" / "S_VAL_PB_NEW.pkl")
    pe = load_wide_panel(basic_root / "AShareEODDerivativeIndicator" / "S_VAL_PE_TTM.pkl")
    margin = load_wide_panel(basic_root / "AShareMarginTrade" / "S_MARGIN_MARGINTRADEBALANCE.pkl")
    limit_status = load_wide_panel(basic_root / "AShareEODDerivativeIndicator" / "UP_DOWN_LIMIT_STATUS.pkl")

    # option stats (轻量)
    opt_stats_path = option_root / "mkt_opt_stats.parquet"
    if opt_stats_path.exists():
        opt_stats = safe_read_parquet(opt_stats_path)
    else:
        opt_stats_path = option_root / "mkt_opt_stats.pkl"
        if not opt_stats_path.exists():
            raise FileNotFoundError("Missing mkt_opt_stats.parquet/.pkl under option_root")
        opt_stats = safe_read_pickle(opt_stats_path)
    if not isinstance(opt_stats, pd.DataFrame):
        raise TypeError(f"期权统计文件不是 DataFrame：{opt_stats_path}")
    # 规范化日期
    opt_stats = opt_stats.copy()
    opt_stats["TRADE_DATE"] = pd.to_datetime(opt_stats["TRADE_DATE"], errors="coerce")
    opt_stats = opt_stats.dropna(subset=["TRADE_DATE"]).sort_values("TRADE_DATE")

    return FeatureInputs(
        trade_mask=trade_mask,
        amount=amount,
        pctchg=pctchg,
        adjclose=adjclose,
        mv=mv,
        pb=pb,
        pe=pe,
        margin=margin,
        limit_status=limit_status,
        opt_stats=opt_stats,
    )

def compute_features(inp: FeatureInputs) -> pd.DataFrame:
    """返回日频特征表（index=交易日）。"""
    # 对齐交易日历：用 amount 的 index 当“主日历”
    calendar = inp.amount.index

    # 对齐各面板
    def align(x: pd.DataFrame) -> pd.DataFrame:
        x2 = x.reindex(calendar)
        return x2

    amount = align(inp.amount)
    pctchg = align(inp.pctchg)
    adjclose = align(inp.adjclose)
    mv = align(inp.mv)
    pb = align(inp.pb)
    pe = align(inp.pe)
    margin = align(inp.margin)
    limit_status = align(inp.limit_status)
    trade_mask = align(inp.trade_mask) if inp.trade_mask is not None else None

    if trade_mask is not None:
        amount = _mask_by_trade(trade_mask, amount)
        pctchg = _mask_by_trade(trade_mask, pctchg)
        adjclose = _mask_by_trade(trade_mask, adjclose)
        mv = _mask_by_trade(trade_mask, mv)
        pb = _mask_by_trade(trade_mask, pb)
        pe = _mask_by_trade(trade_mask, pe)
        margin = _mask_by_trade(trade_mask, margin)
        limit_status = _mask_by_trade(trade_mask, limit_status)

    # ========== A 资金：成交额 ==========
    amt_total = amount.sum(axis=1, skipna=True, min_count=1)
    amt_trend = np.log(amt_total / amt_total.rolling(20, min_periods=5).mean())

    # ========== B 杠杆：融资融券余额 ==========
    margin_total = margin.sum(axis=1, skipna=True, min_count=1)

    # 两融通常 T+1 更新：若最新交易日缺失，沿用上一日（最多 limit 天）

    if ASYNC_FFILL_LIMIT and ASYNC_FFILL_LIMIT > 0:

        if (not ASYNC_FFILL_ONLY_IF_LAST_DAY_MISSING) or pd.isna(margin_total.iloc[-1]):

            margin_total = ffill_tail(margin_total, limit=ASYNC_FFILL_LIMIT)

    margin_chg_20d = margin_total.pct_change(20)

    # ========== C 广度 ==========
    adv_ratio = (pctchg > 0).mean(axis=1, skipna=True)

    ma20 = adjclose.rolling(20, min_periods=10).mean()
    above_ma20 = (adjclose > ma20).mean(axis=1, skipna=True)

    # 涨跌停
    # 注意：不同数据源编码可能不同（config 里可改）
    limit_up = (limit_status == LIMIT_UP_CODE).sum(axis=1, skipna=True)
    limit_down = (limit_status == LIMIT_DOWN_CODE).sum(axis=1, skipna=True)
    total_cnt = limit_status.notna().sum(axis=1)
    limit_down_ratio = (limit_down / total_cnt.replace(0, np.nan)).fillna(0.0)

    # ========== D 估值（市值加权 PB/PE） ==========
    mv_pos = mv.where(mv > 0)
    pb_pos = pb.where(pb > 0)
    pe_pos = pe.where(pe > 0)

    w = mv_pos
    pb_wavg = (pb_pos * w).sum(axis=1, skipna=True) / w.sum(axis=1, skipna=True)
    pe_wavg = (pe_pos * w).sum(axis=1, skipna=True) / w.sum(axis=1, skipna=True)

    # ========== E 期权情绪 ==========
    # opt_stats: 多 security_id，按 trade_date 聚合
    os = inp.opt_stats.copy()
    # 只保留日频统计（一般 STATS_INTERVAL=1；如不一致可放开）
    if "STATS_INTERVAL" in os.columns:
        os = os[os["STATS_INTERVAL"].astype("Int64") == 1]

    os["PC_RATE"] = pd.to_numeric(os["PC_RATE"], errors="coerce")
    # 聚合：用 TURNOVER_VOL 做权重
    os["TURNOVER_VOL"] = pd.to_numeric(os["TURNOVER_VOL"], errors="coerce")
    os["OPEN_INT"] = pd.to_numeric(os["OPEN_INT"], errors="coerce")

    # groupby.apply 在 pandas 新版本会触发 FutureWarning（且更慢），改为向量化加权平均：
    # pc_rate = sum(PC_RATE * TURNOVER_VOL) / sum(TURNOVER_VOL)
    g = os.groupby("TRADE_DATE", sort=True)
    opt_turnover = g["TURNOVER_VOL"].sum(min_count=1)
    opt_oi = g["OPEN_INT"].sum(min_count=1)

    num = (os["PC_RATE"] * os["TURNOVER_VOL"]).groupby(os["TRADE_DATE"]).sum(min_count=1)
    den = os["TURNOVER_VOL"].groupby(os["TRADE_DATE"]).sum(min_count=1)
    pc_rate = (num / den.replace(0, np.nan))
    pc_rate.name = "pc_rate"

    call_put_ratio = 1.0 / pc_rate.replace(0, np.nan)
    opt_turnover_to_oi = opt_turnover / opt_oi.replace(0, np.nan)

    # 对齐到主日历并 ffill（期权可能缺一些交易日）
    opt_df = pd.concat([call_put_ratio, opt_turnover, opt_turnover_to_oi], axis=1)
    opt_df.columns = ["call_put_ratio", "opt_turnover", "opt_turnover_to_oi"]
    opt_df = opt_df.reindex(calendar).ffill()

    feat = pd.DataFrame(index=calendar)
    feat["amt_total"] = amt_total
    feat["amt_trend"] = amt_trend
    feat["margin_total"] = margin_total
    feat["margin_chg_20d"] = margin_chg_20d
    feat["adv_ratio"] = adv_ratio
    feat["above_ma20"] = above_ma20
    feat["limit_down_ratio"] = limit_down_ratio
    feat["pb_wavg"] = pb_wavg
    feat["pe_wavg"] = pe_wavg
    feat = feat.join(opt_df, how="left")

    # 一些稳定处理：对数
    for col in ["amt_total", "margin_total", "opt_turnover"]:
        feat[col] = np.log1p(feat[col])

    feat = _apply_async_ffill(
        feat,
        cols=list(ASYNC_FFILL_COLS),
        limit=ASYNC_FFILL_LIMIT,
        only_if_last_day_missing=ASYNC_FFILL_ONLY_IF_LAST_DAY_MISSING,
        stale_warn_days=ASYNC_STALE_WARN_DAYS,
    )

    return feat

def compute_market_proxy(inp: FeatureInputs, option_root: Path) -> pd.Series:
    s = market_proxy_from_fund(option_root, ticker=MARKET_PROXY_TICKER)
    if s is not None:
        return s
    # fallback 等权代理
    trade_mask = inp.trade_mask
    return market_proxy_equal_weight(inp.adjclose, trade_mask=trade_mask)
