# -*- coding: utf-8 -*-
from __future__ import annotations

from pathlib import Path
import numpy as np
import pandas as pd

from ..config import OUTPUT_ROOT


def _read_opt_daily_factors(out_root: Path) -> pd.DataFrame:
    """Optional cache produced by scripts/build_opt_daily_factors.py."""
    p = out_root / "overheat" / "opt_daily_factors.parquet"
    if not p.exists():
        return pd.DataFrame()
    try:
        df = pd.read_parquet(p)
    except Exception:
        return pd.DataFrame()
    if df is None or df.empty:
        return pd.DataFrame()
    if "date" in df.columns and df.index.name != "date":
        df = df.set_index("date")
    df.index = pd.to_datetime(df.index, errors="coerce")
    df = df[~df.index.isna()].sort_index()
    return df


def compute_features(opt_stats: pd.DataFrame, calendar: pd.DatetimeIndex, out_root: Path | None = None) -> pd.DataFrame:
    """
    E_Options (deepened, backward compatible):
    - From mkt_opt_stats.parquet (or .pkl): volume/OI based sentiment & crowdedness.
    - Optionally joins cached daily factors (ivix/skew/gamma...) if present.

    Returns daily DF indexed by `calendar`.
    """
    out_root = out_root or OUTPUT_ROOT

    os = opt_stats.copy()
    if "STATS_INTERVAL" in os.columns:
        si =pd.to_numeric(os["STATS_INTERVAL"],errors="coerce")
        if (si == 4).any():
            os = os[si ==4]
        else:
            os = os[si == si.max()]

    for c in ["TURNOVER_VOL","OPEN_INT","C_VOL","P_VOL","C_OPEN_INT","P_OPEN_INT"]:
        if c in os.columns:
            os[c] = pd.to_numeric(os[c], errors="coerce")

    g = os.groupby("TRADE_DATE", sort=True)
    daily = pd.DataFrame(index=g.size().index)
    daily["opt_turnover"] = g["TURNOVER_VOL"].sum(min_count=1)
    daily["opt_oi"] = g["OPEN_INT"].sum(min_count=1)
    daily["call_vol"] = g["C_VOL"].sum(min_count=1)
    daily["put_vol"] = g["P_VOL"].sum(min_count=1)
    daily["call_oi"] = g["C_OPEN_INT"].sum(min_count=1)
    daily["put_oi"] = g["P_OPEN_INT"].sum(min_count=1)

    daily.index = pd.to_datetime(daily.index, errors="coerce")
    daily = daily[~daily.index.isna()].sort_index()
    daily = daily.reindex(calendar).ffill(limit=1)

    # Compatible fields
    call_put_ratio = (daily["call_vol"] / daily["put_vol"].replace(0, np.nan)).replace([np.inf, -np.inf], np.nan)
    call_put_oi_ratio = (daily["call_oi"] / daily["put_oi"].replace(0, np.nan)).replace([np.inf, -np.inf], np.nan)
    opt_turnover_to_oi = (daily["opt_turnover"] / daily["opt_oi"].replace(0, np.nan)).replace([np.inf, -np.inf], np.nan)

    # V2 fields
    pcr_vol_hot = np.log1p(daily["call_vol"]) - np.log1p(daily["put_vol"])
    pcr_oi_hot = np.log1p(daily["call_oi"]) - np.log1p(daily["put_oi"])

    opt_oi_log = np.log(daily["opt_oi"].replace(0, np.nan))
    opt_oi_chg_5d = opt_oi_log.diff(5)

    opt_turnover_ma20 = daily["opt_turnover"].rolling(20, min_periods=5).mean()
    opt_vol_surge = np.log1p(daily["opt_turnover"]) - np.log1p(opt_turnover_ma20)

    base = pd.DataFrame(index=calendar)
    base["call_put_ratio"] = call_put_ratio
    base["call_put_oi_ratio"] = call_put_oi_ratio
    base["opt_turnover"] = daily["opt_turnover"]
    base["opt_turnover_to_oi"] = opt_turnover_to_oi

    base["pcr_vol_hot"] = pcr_vol_hot
    base["pcr_oi_hot"] = pcr_oi_hot
    base["opt_oi_chg_5d"] = opt_oi_chg_5d
    base["opt_vol_surge"] = opt_vol_surge

    # Optional join: ivix/skew/gamma...
    extra = _read_opt_daily_factors(out_root)
    if not extra.empty:
        base = base.join(extra.reindex(calendar), how="left")
        if "ivix_30d" in base.columns and "ivix_low_hot" not in base.columns:
            base["ivix_low_hot"] = -pd.to_numeric(base["ivix_30d"], errors="coerce")

    return base
