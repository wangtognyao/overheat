# -*- coding: utf-8 -*-
from __future__ import annotations

from pathlib import Path
import pandas as pd

from ..macro import compute_macro_features as _compute_macro_features
from ..config import FEATURE_WEIGHTS


def compute_features(macro_root: Path, calendar: pd.DatetimeIndex) -> pd.DataFrame:
    """M_Macro: compute daily macro features aligned to the trading calendar."""
    df = _compute_macro_features(macro_root=macro_root, calendar=calendar)
    if df is None or df.empty:
        return pd.DataFrame(index=calendar)

    df = df.reindex(calendar)
    for c in df.columns:
        df[c] = pd.to_numeric(df[c], errors="coerce")

    wanted = list(FEATURE_WEIGHTS.get("M_Macro", {}).keys())
    keep = [c for c in wanted if c in df.columns]
    if not keep:
        return pd.DataFrame(index=calendar)

    return df[keep]
