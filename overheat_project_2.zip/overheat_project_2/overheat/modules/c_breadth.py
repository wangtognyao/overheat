# -*- coding: utf-8 -*-
from __future__ import annotations

import numpy as np
import pandas as pd

from ..config import LIMIT_DOWN_CODE


def compute_features(pctchg: pd.DataFrame, adjclose: pd.DataFrame, limit_status: pd.DataFrame) -> pd.DataFrame:
    """C_Breadth: adv ratio, above MA20 ratio, limit-down ratio."""
    adv_ratio = (pctchg > 0).mean(axis=1, skipna=True)

    ma20 = adjclose.rolling(20, min_periods=10).mean()
    above_ma20 = (adjclose > ma20).mean(axis=1, skipna=True)

    limit_down = (limit_status == LIMIT_DOWN_CODE).sum(axis=1, skipna=True)
    total_cnt = limit_status.notna().sum(axis=1)
    limit_down_ratio = (limit_down / total_cnt.replace(0, np.nan)).fillna(0.0)

    out = pd.DataFrame(index=pctchg.index)
    out["adv_ratio"] = adv_ratio
    out["above_ma20"] = above_ma20
    out["limit_down_ratio"] = limit_down_ratio
    return out
