# -*- coding: utf-8 -*-
from __future__ import annotations

import pandas as pd


def compute_features(mv: pd.DataFrame, pb: pd.DataFrame, pe: pd.DataFrame) -> pd.DataFrame:
    """D_Valuation: market-cap weighted PB and PE (TTM)."""
    mv_pos = mv.where(mv > 0)
    pb_pos = pb.where(pb > 0)
    pe_pos = pe.where(pe > 0)

    w = mv_pos
    pb_wavg = (pb_pos * w).sum(axis=1, skipna=True) / w.sum(axis=1, skipna=True)
    pe_wavg = (pe_pos * w).sum(axis=1, skipna=True) / w.sum(axis=1, skipna=True)

    out = pd.DataFrame(index=mv.index)
    out["pb_wavg"] = pb_wavg
    out["pe_wavg"] = pe_wavg
    return out
