# -*- coding: utf-8 -*-
from __future__ import annotations

import numpy as np
import pandas as pd


def compute_features(amount: pd.DataFrame) -> pd.DataFrame:
    """A_Funds: turnover amount level + trend."""
    amt_total = amount.sum(axis=1, skipna=True, min_count=1)
    amt_trend = np.log(amt_total / amt_total.rolling(20, min_periods=5).mean())
    out = pd.DataFrame(index=amount.index)
    out["amt_total"] = amt_total
    out["amt_trend"] = amt_trend
    return out
