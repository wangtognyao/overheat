# -*- coding: utf-8 -*-
from __future__ import annotations

import pandas as pd

from ..config import ASYNC_FFILL_LIMIT, ASYNC_FFILL_ONLY_IF_LAST_DAY_MISSING
from ..feature_utils import ffill_tail


def compute_features(margin: pd.DataFrame) -> pd.DataFrame:
    """B_Leverage: margin financing balance level + 20d change."""
    margin_total = margin.sum(axis=1, skipna=True, min_count=1)

    if ASYNC_FFILL_LIMIT and ASYNC_FFILL_LIMIT > 0:
        if (not ASYNC_FFILL_ONLY_IF_LAST_DAY_MISSING) or pd.isna(margin_total.iloc[-1]):
            margin_total = ffill_tail(margin_total, limit=ASYNC_FFILL_LIMIT)

    margin_chg_20d = margin_total.pct_change(20, fill_method=None)

    out = pd.DataFrame(index=margin.index)
    out["margin_total"] = margin_total
    out["margin_chg_20d"] = margin_chg_20d
    return out
