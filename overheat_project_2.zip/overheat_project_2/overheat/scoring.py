# -*- coding: utf-8 -*-
from __future__ import annotations

import numpy as np
import pandas as pd

from .config import (
    ROLLING_Z_WIN, Z_CLIP, MIN_HISTORY,
    MODULE_WEIGHTS, FEATURE_WEIGHTS, FEATURE_DIRECTION_POSITIVE
)

def rolling_zscore(s: pd.Series, win: int = ROLLING_Z_WIN) -> pd.Series:
    mu = s.rolling(win, min_periods=max(20, win//4)).mean()
    sd = s.rolling(win, min_periods=max(20, win//4)).std(ddof=0)
    z = (s - mu) / sd.replace(0, np.nan)
    z = z.clip(-Z_CLIP, Z_CLIP)
    return z

def z_to_score(z: pd.Series) -> pd.Series:
    z = pd.to_numeric(z, errors="coerce")              # 关键：强转数值
    arr = z.to_numpy(dtype=float)                      # 关键：转 numpy float
    out = 100.0 / (1.0 + np.exp(-arr))
    return pd.Series(out, index=z.index)

def score_feature(feat: pd.Series, positive: bool) -> pd.Series:
    z = rolling_zscore(feat)
    if not positive:
        z = -z
    score = z_to_score(z)
    # 早期历史不足：不出分
    score = score.where(feat.expanding().count() >= MIN_HISTORY)
    return score

def _weighted_mean_by_row(df: pd.DataFrame, weights: dict[str, float]) -> pd.Series:
    cols = [c for c in weights.keys() if c in df.columns]
    if not cols:
        return pd.Series(index=df.index, dtype=float)
    w = np.array([weights[c] for c in cols], dtype=float)
    w = w / (w.sum() if w.sum() != 0 else 1.0)
    x = df[cols]
    num = (x.values * w).astype(float)
    num = np.nansum(num, axis=1)
    denom = np.nansum((~np.isnan(x.values)) * w, axis=1)
    out = num / np.where(denom == 0, np.nan, denom)
    return pd.Series(out, index=df.index)

def compute_scores(features: pd.DataFrame) -> tuple[pd.DataFrame, pd.DataFrame]:
    """返回：(feature_scores, module_and_total_scores)

    规则：
    - 特征分：若该特征历史不足 MIN_HISTORY -> NaN
    - 模块分：按可用特征的权重 **动态归一化**（当天缺一个特征，不会让模块直接 NaN）
    - 总分：按可用模块权重动态归一化（某模块当天 NaN，则自动用剩余模块）
    """
    f_scores = pd.DataFrame(index=features.index)

    # 逐特征打分
    for col in features.columns:
        pos = FEATURE_DIRECTION_POSITIVE.get(col, True)
        f_scores[col] = score_feature(features[col], positive=pos)

    # 模块分
    m_scores = pd.DataFrame(index=features.index)
    for mod, wdict in FEATURE_WEIGHTS.items():
        m_scores[mod] = _weighted_mean_by_row(f_scores, wdict)

    # 总分
    mods = [m for m in MODULE_WEIGHTS.keys() if m in m_scores.columns]
    if mods:
        total = _weighted_mean_by_row(m_scores[mods], {m: MODULE_WEIGHTS[m] for m in mods})
        m_scores["OverheatScore"] = total
    else:
        m_scores["OverheatScore"] = np.nan

    return f_scores, m_scores
