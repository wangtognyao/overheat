# -*- coding: utf-8 -*-
from __future__ import annotations

from dataclasses import dataclass
from pathlib import Path

# ========== 你需要确认/可能需要修改的路径 ==========
# 这些路径来源于你提供的数据清单（data_basic.json / data_option.json / data_macro.json / data_pkl.json）
DATA_ROOT = Path("/data/wangtongyao/factor_test/data")

BASIC_ROOT = DATA_ROOT / "basic_data"
OPTION_ROOT = DATA_ROOT / "option_data"
MACRO_ROOT = DATA_ROOT / "macro_data"
PKL_ROOT = DATA_ROOT / "pkl_data"

OUTPUT_ROOT = Path("./output")   # 建议在项目目录下；也可改成 /data/.../output

# ========== 市场代理价格（用于画图叠加） ==========
# 优先在 option_data/mkt_fundd.pkl 里找这个 ticker（例如 510300）
# 若不存在，会自动退化为“全市场等权”代理
MARKET_PROXY_TICKER = "510300"

# ========== 过热分区（用于文案） ==========
HOT_LINE = 75
WARM_LINE = 55
COOL_LINE = 35

# ========== 打分超参数 ==========
ROLLING_Z_WIN = 252      # 约1年
Z_CLIP = 3.0             # 防止极端值把分数拉爆
MIN_HISTORY = 120        # 少于该历史长度则不出分（避免刚开始上线时乱跳）

# ========== 模块权重（可按你与领导习惯微调） ==========
MODULE_WEIGHTS = {
    "M_Macro": 0.00,  # 默认不进总分；如需纳入可改成例如 0.10 并相应调低其它权重
    "A_Funds": 0.25,
    "B_Leverage": 0.15,
    "C_Breadth": 0.25,
    "D_Valuation": 0.20,
    "E_Options": 0.15,
}

# ========== 子指标权重（模块内部） ==========
FEATURE_WEIGHTS = {
    "M_Macro": {
        "dr007": 0.06,
        "cgb10y": 0.05,
        "lpr_1y": 0.05,
        "shibor_3m": 0.04,
        "term_spread": 0.05,
        "credit_spread_1y": 0.05,
        "m2_sa": 0.06,
        "m1_sa": 0.04,
        "m2_m1_gap": 0.04,
        "mlf_net_injection": 0.04,
        "cpi": 0.05,
        "ppi": 0.04,
        "cpi_ppi_gap": 0.03,
        "pmi": 0.05,
        "industrial_va": 0.04,
        "retail_sales": 0.04,
        "unemp_urban": 0.04,
        "usdcny": 0.04,
        "dxy": 0.03,
        "gold_spot": 0.03,
        "us10y": 0.03,
    },

    "A_Funds": {
        "amt_total": 0.55,
        "amt_trend": 0.45,
    },
    "B_Leverage": {
        "margin_total": 0.60,
        "margin_chg_20d": 0.40,
    },
    "C_Breadth": {
        "adv_ratio": 0.40,
        "above_ma20": 0.40,
        "limit_down_ratio": 0.20,   # 负向指标：跌停越多越“冷”
    },
    "D_Valuation": {
        "pb_wavg": 0.55,
        "pe_wavg": 0.45,
    },
    "E_Options": {
        "call_put_ratio": 0.45,     # 期权情绪：call更拥挤 -> 更热
        "opt_turnover": 0.30,
        "opt_turnover_to_oi": 0.25,
    },
}

# ========== 指标方向：True 表示“越大越热”；False 表示“越大越冷”（会自动取负号） ==========
FEATURE_DIRECTION_POSITIVE = {
    "dr007": False,
    "cgb10y": False,
    "lpr_1y": False,
    "shibor_3m": False,
    "term_spread": True,
    "credit_spread_1y": False,
    "m2_sa": True,
    "m1_sa": True,
    "m2_m1_gap": False,
    "mlf_net_injection": True,
    "cpi": True,
    "ppi": True,
    "cpi_ppi_gap": True,
    "pmi": True,
    "industrial_va": True,
    "retail_sales": True,
    "unemp_urban": False,
    "usdcny": False,
    "dxy": False,
    "gold_spot": False,
    "us10y": False,

    "amt_total": True,
    "amt_trend": True,
    "margin_total": True,
    "margin_chg_20d": True,
    "adv_ratio": True,
    "above_ma20": True,
    "limit_down_ratio": False,
    "pb_wavg": True,
    "pe_wavg": True,
    "call_put_ratio": True,
    "opt_turnover": True,
    "opt_turnover_to_oi": True,
}

# ========== Wind 的涨跌停状态编码（如与你的数据不一致，可改） ==========
# UP_DOWN_LIMIT_STATUS 常见：1=涨停，-1=跌停，其它=0（不同口径会有差异）
LIMIT_UP_CODE = 1
LIMIT_DOWN_CODE = -1

@dataclass(frozen=True)
class Paths:
    basic_root: Path = BASIC_ROOT
    option_root: Path = OPTION_ROOT
    macro_root: Path = MACRO_ROOT
    pkl_root: Path = PKL_ROOT
    out_root: Path = OUTPUT_ROOT


# ========== 文案显示名 ==========
MODULE_LABELS = {
    "A_Funds": "A 资金",
    "B_Leverage": "B 杠杆",
    "C_Breadth": "C 广度",
    "D_Valuation": "D 估值",
    "E_Options": "E 期权",
    "M_Macro": "M 宏观",
}

FEATURE_LABELS = {
    "amt_total": "成交额总量",
    "amt_trend": "成交额趋势",
    "margin_total": "两融余额",
    "margin_chg_20d": "两融20日变化",
    "adv_ratio": "上涨家数占比",
    "above_ma20": "站上20日均线占比",
    "limit_down_ratio": "跌停占比",
    "pb_wavg": "PB(市值加权)",
    "pe_wavg": "PE_TTM(市值加权)",
    "call_put_ratio": "Call/Put(情绪)",
    "opt_turnover": "期权成交量",
    "opt_turnover_to_oi": "期权成交/持仓",
    "dr007": "DR007",
    "cgb10y": "10Y国开收益率",
    "usdcny": "USD/CNY中间价",
    "dxy": "DXY",
}
FEATURE_LABELS.update({
    "lpr_1y": "LPR 1Y",
    "shibor_3m": "SHIBOR 3M",
    "term_spread": "10Y-DR007 spread",
    "credit_spread_1y": "AAA1Y-10Y spread",
    "m2_sa": "M2 SA",
    "m1_sa": "M1 SA",
    "m2_m1_gap": "M2-M1 gap",
    "mlf_net_injection": "MLF net injection",
    "cpi": "CPI fixed base",
    "ppi": "PPI fixed base",
    "cpi_ppi_gap": "CPI-PPI gap",
    "pmi": "PMI manufacturing",
    "industrial_va": "Industrial VA fixed base",
    "retail_sales": "Retail sales total",
    "unemp_urban": "Urban unemployment 31 cities",
    "gold_spot": "Gold spot USD",
    "us10y": "US 10Y",
})
# ============================
# 异步更新数据（T+1）处理规则
# ============================

# 你要把 “两融相关特征列名” 填到这里（列名来自 features.columns）
ASYNC_FFILL_COLS = [
    "margin_total",
    "margin_chg_20d",
    # 举例（你需要换成你真实的列名）
    # "margin_balance",
    # "margin_buy",
    # "short_balance",
]

# 最多允许沿用几天：两融一般 1 天足够（T 日收盘拿不到 T 日两融）
ASYNC_FFILL_LIMIT = 1

# 是否只在“最后一天缺失”时才触发沿用（强烈建议 True，更安全）
ASYNC_FFILL_ONLY_IF_LAST_DAY_MISSING = True

# 如果某列滞后 >= 2 天，就给你一个 warning（防止数据卡住你没发现）
ASYNC_STALE_WARN_DAYS = 2
