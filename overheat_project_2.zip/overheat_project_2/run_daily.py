# -*- coding: utf-8 -*-
from __future__ import annotations

import argparse
from pathlib import Path

import pandas as pd

from overheat.config_v2 import Paths
from overheat.features import load_inputs, compute_features, compute_market_proxy
from overheat.scoring import compute_scores
from overheat.plotting import plot_overheat, plot_subscores
from overheat.reporting import make_daily_message


def _save_csv(df: pd.DataFrame, path: Path) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    df.to_csv(path, encoding="utf-8-sig")


def main() -> None:
    ap = argparse.ArgumentParser()
    ap.add_argument("--mode", choices=["full", "incremental"], default="incremental")
    ap.add_argument("--out_dir", type=str, default="", help="Override output dir (default: config.OUTPUT_ROOT/overheat)")
    args = ap.parse_args()

    paths = Paths()
    out_dir = Path(args.out_dir) if args.out_dir else (paths.out_root / "overheat")
    out_dir.mkdir(parents=True, exist_ok=True)

    inp = load_inputs(paths.basic_root, paths.option_root, paths.pkl_root)
    feat = compute_features(inp)

    f_scores, m_scores = compute_scores(feat)

    _save_csv(feat, out_dir / "features.csv")
    _save_csv(f_scores, out_dir / "feature_scores.csv")
    _save_csv(m_scores, out_dir / "scores.csv")

    proxy = compute_market_proxy(inp, paths.option_root)
    plot_overheat(proxy, m_scores, out_dir / "overheat.png", title="OverheatScore")
    plot_subscores(m_scores, out_dir / "modules.png", title="Module Scores")

    msg = make_daily_message(m_scores, f_scores)
    (out_dir / "daily_message.txt").write_text(msg, encoding="utf-8")
    print(msg)


if __name__ == "__main__":
    main()
