import pandas as pd
from pathlib import Path

def export_last_n(path: str, n: int = 20):
    p = Path(path)
    df = pd.read_csv(p)
    df["trade_dt"] = pd.to_datetime(df["trade_dt"])
    df = df.sort_values("trade_dt").tail(n)
    out = p.with_name(f"{p.stem}_last{n}{p.suffix}")
    df.to_csv(out, index=False, encoding="utf-8-sig")
    print("saved:", out)

if __name__ == "__main__":
    n = 20  # 改成 10/20/60/252 都行
    export_last_n("/data/wangtongyao/overheat_new/overheat_project_2/output/overheat/scores.csv", n)
    export_last_n("/data/wangtongyao/overheat_new/overheat_project_2/output/overheat/feature_scores.csv", n)
    export_last_n("/data/wangtongyao/overheat_new/overheat_project_2/output/overheat/features.csv", n)
    export_last_n("/data/wangtongyao/overheat_new/overheat_project_2/overheat_industry/output/industry_modules.csv", n)